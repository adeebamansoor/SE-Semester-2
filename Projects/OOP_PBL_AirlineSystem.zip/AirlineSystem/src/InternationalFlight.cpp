#include "InternationalFlight.h"
#include "Utilities.h"
#include <iostream>
#include <sstream>

InternationalFlight::InternationalFlight(const std::string& flightNumber,
                                          const std::string& origin,
                                          const std::string& destination,
                                          const std::string& departureDateTime,
                                          int    totalSeats,
                                          double distanceKm,
                                          bool   visaRequired,
                                          double fuelSurcharge,
                                          double pricePerKm)
    : Flight(flightNumber, origin, destination, departureDateTime, totalSeats),
      visaRequired(visaRequired),
      fuelSurcharge(fuelSurcharge),
      distanceKm(distanceKm),
      pricePerKm(pricePerKm)
{}

double InternationalFlight::calculateBaseFare() const {
    return (distanceKm * pricePerKm) + fuelSurcharge;
}

void InternationalFlight::displayDetails() const {
    printDivider();
    std::cout << "  [INTERNATIONAL FLIGHT]\n";
    std::cout << "  Flight No      : " << flightNumber << "\n";
    std::cout << "  Route          : " << origin << " -> " << destination << "\n";
    std::cout << "  Departure      : " << departureDateTime << "\n";
    std::cout << "  Seats          : " << availableSeats << " / " << totalSeats << " available\n";
    std::cout << "  Distance       : " << distanceKm << " km\n";
    std::cout << "  Visa Required  : " << (visaRequired ? "YES" : "NO") << "\n";
    std::cout << "  Fuel Surcharge : " << formatCurrency(fuelSurcharge) << "\n";
    std::cout << "  Base Fare      : " << formatCurrency(calculateBaseFare()) << "\n";
    printDivider();
}

std::string InternationalFlight::serialize() const {
    // TYPE|flightNumber|origin|destination|departureDateTime|totalSeats|availableSeats|distanceKm|visaRequired|fuelSurcharge|pricePerKm
    std::ostringstream oss;
    oss << getType() << "|"
        << flightNumber << "|"
        << origin << "|"
        << destination << "|"
        << departureDateTime << "|"
        << totalSeats << "|"
        << availableSeats << "|"
        << distanceKm << "|"
        << visaRequired << "|"
        << fuelSurcharge << "|"
        << pricePerKm;
    return oss.str();
}
