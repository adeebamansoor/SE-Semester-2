#include <iostream>
#include <string>
#include <limits>
#include <memory>
#include <stdexcept>

#include "Airline.h"
#include "DomesticFlight.h"
#include "InternationalFlight.h"
#include "CharterFlight.h"
#include "EconomyPassenger.h"
#include "BusinessPassenger.h"
#include "FirstClassPassenger.h"
#include "Utilities.h"
#include "Exceptions.h"

// ======================== INPUT HELPERS ========================

static std::string getStringInput(const std::string& prompt) {
    std::string val;
    std::cout << "  " << prompt;
    std::getline(std::cin, val);
    return trim(val);
}

static int getIntInput(const std::string& prompt) {
    int val;
    while (true) {
        std::cout << "  " << prompt;
        if (std::cin >> val) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return val;
        }
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "  [ERROR] Please enter a valid integer.\n";
    }
}

static double getDoubleInput(const std::string& prompt) {
    double val;
    while (true) {
        std::cout << "  " << prompt;
        if (std::cin >> val) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return val;
        }
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "  [ERROR] Please enter a valid number.\n";
    }
}

// ======================== FLIGHT ADDITION ========================

static void handleAddFlight(Airline& airline) {
    printHeader("ADD FLIGHT");
    std::cout << "  Flight Type: 1=Domestic  2=International  3=Charter\n";
    int type = getIntInput("Type: ");

    std::string num  = getStringInput("Flight Number: ");
    std::string orig = getStringInput("Origin: ");
    std::string dest = getStringInput("Destination: ");
    std::string dep  = getStringInput("Departure (YYYY-MM-DD HH:MM): ");
    int seats        = getIntInput("Total Seats: ");

    try {
        if (type == 1) {
            double dist = getDoubleInput("Distance (km): ");
            double rate = getDoubleInput("Price per km (default 8.5): ");
            airline.addFlight(std::make_shared<DomesticFlight>(num, orig, dest, dep, seats, dist, rate));
        }
        else if (type == 2) {
            double dist  = getDoubleInput("Distance (km): ");
            int    visa  = getIntInput("Visa Required? (1=Yes 0=No): ");
            double surcharge = getDoubleInput("Fuel Surcharge (default 5000): ");
            double rate  = getDoubleInput("Price per km (default 12.0): ");
            airline.addFlight(std::make_shared<InternationalFlight>(
                num, orig, dest, dep, seats, dist, static_cast<bool>(visa), surcharge, rate));
        }
        else if (type == 3) {
            std::string contract = getStringInput("Contract Holder: ");
            double price = getDoubleInput("Total Charter Price: ");
            airline.addFlight(std::make_shared<CharterFlight>(num, orig, dest, dep, seats, contract, price));
        }
        else {
            std::cout << "  [ERROR] Invalid flight type.\n";
        }
    } catch (const std::exception& e) {
        std::cout << "  [ERROR] " << e.what() << "\n";
    }
}

// ======================== PASSENGER REGISTRATION ========================

static void handleRegisterPassenger(Airline& airline) {
    printHeader("REGISTER PASSENGER");
    std::cout << "  Class: 1=Economy  2=Business  3=FirstClass\n";
    int cls = getIntInput("Class: ");

    std::string id    = getStringInput("Passenger ID: ");
    std::string name  = getStringInput("Full Name: ");
    std::string email = getStringInput("Email: ");
    std::string phone = getStringInput("Phone: ");

    try {
        if (cls == 1)
            airline.addPassenger(std::make_shared<EconomyPassenger>(id, name, email, phone));
        else if (cls == 2)
            airline.addPassenger(std::make_shared<BusinessPassenger>(id, name, email, phone));
        else if (cls == 3)
            airline.addPassenger(std::make_shared<FirstClassPassenger>(id, name, email, phone));
        else
            std::cout << "  [ERROR] Invalid class.\n";
    } catch (const std::exception& e) {
        std::cout << "  [ERROR] " << e.what() << "\n";
    }
}

// ======================== MAIN ========================

int main() {
    Airline airline("SkyLink Airways");

    // Load persisted state on startup
    std::cout << "\n  Loading saved data...\n";
    try {
        airline.loadFromFile();
        std::cout << "  [OK] Data loaded.\n";
    } catch (const FileIOException& e) {
        std::cout << "  [INFO] No saved data found — starting fresh.\n";
    } catch (const std::exception& e) {
        std::cout << "  [WARN] Could not load data: " << e.what() << "\n";
    }

    int choice = 0;
    while (choice != 17) {
        airline.displayMenu();

        if (!(std::cin >> choice)) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "  [ERROR] Please enter a number.\n";
            continue;
        }
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        try {
            switch (choice) {

            // ---- FLIGHTS ----
            case 1:
                handleAddFlight(airline);
                break;

            case 2: {
                std::string num = getStringInput("Flight Number to remove: ");
                if (airline.removeFlight(num))
                    std::cout << "  [OK] Flight removed.\n";
                else
                    std::cout << "  [ERROR] Flight not found.\n";
                break;
            }

            case 3: {
                std::string num = getStringInput("Flight Number: ");
                auto f = airline.searchFlightByNumber(num);
                if (f) std::cout << *f;
                else   std::cout << "  [ERROR] Flight not found.\n";
                break;
            }

            case 4: {
                std::string orig = getStringInput("Origin: ");
                std::string dest = getStringInput("Destination: ");
                auto results = airline.searchFlightsByRoute(orig, dest);
                if (results.empty()) std::cout << "  No flights found.\n";
                else for (auto* f : results) f->displayDetails();
                break;
            }

            case 5: {
                std::string date = getStringInput("Date (YYYY-MM-DD): ");
                airline.reportTodaysDepartures(date);
                break;
            }

            case 6:
                airline.listAllFlights();
                break;

            // ---- PASSENGERS ----
            case 7:
                handleRegisterPassenger(airline);
                break;

            case 8: {
                std::string id = getStringInput("Passenger ID to remove: ");
                if (airline.removePassenger(id))
                    std::cout << "  [OK] Passenger removed.\n";
                else
                    std::cout << "  [ERROR] Passenger not found.\n";
                break;
            }

            case 9: {
                std::string id = getStringInput("Passenger ID: ");
                auto p = airline.searchPassengerById(id);
                if (p) std::cout << *p;
                else   std::cout << "  [ERROR] Passenger not found.\n";
                break;
            }

            case 10: {
                std::string id = getStringInput("Passenger ID: ");
                airline.showBookingHistory(id);
                break;
            }

            case 11:
                airline.listAllPassengers();
                break;

            // ---- BOOKINGS ----
            case 12: {
                std::string pid = getStringInput("Passenger ID: ");
                std::string flt = getStringInput("Flight Number: ");
                airline.bookTicket(pid, flt);
                break;
            }

            case 13: {
                std::string tid = getStringInput("Ticket ID to cancel: ");
                int hours = getIntInput("Hours before departure: ");
                double refund = airline.cancelTicket(tid, hours);
                std::cout << "  [OK] Ticket cancelled. Refund: " << formatCurrency(refund) << "\n";
                break;
            }

            // ---- REPORTS ----
            case 14: {
                std::string today = getStringInput("Date for report (YYYY-MM-DD): ");
                airline.reportTodaysDepartures(today);
                break;
            }

            case 15:
                airline.reportOccupancyPerFlight();
                break;

            case 16:
                airline.reportTop5RevenueFlights();
                break;

            // ---- SYSTEM ----
            case 17:
                try {
                    airline.saveToFile();
                } catch (const std::exception& e) {
                    std::cout << "  [ERROR] Could not save: " << e.what() << "\n";
                }
                std::cout << "\n  Goodbye!\n\n";
                break;

            default:
                std::cout << "  [ERROR] Invalid choice. Please try again.\n";
            }

        } catch (const FlightFullException& e) {
            std::cout << "  [BOOKING ERROR] " << e.what() << "\n";
        } catch (const DuplicateBookingException& e) {
            std::cout << "  [BOOKING ERROR] " << e.what() << "\n";
        } catch (const InvalidCancellationException& e) {
            std::cout << "  [CANCEL ERROR] " << e.what() << "\n";
        } catch (const std::exception& e) {
            std::cout << "  [ERROR] " << e.what() << "\n";
        }
    }

    return 0;
}
