#include "Flight.h"
#include <stdexcept>

Flight::Flight(const std::string& flightNumber,
               const std::string& origin,
               const std::string& destination,
               const std::string& departureDateTime,
               int totalSeats)
    : flightNumber(flightNumber),
      origin(origin),
      destination(destination),
      departureDateTime(departureDateTime),
      totalSeats(totalSeats),
      availableSeats(totalSeats)
{
    if (totalSeats <= 0)
        throw std::invalid_argument("Total seats must be positive.");
}

bool Flight::bookSeat() {
    if (availableSeats <= 0) return false;
    --availableSeats;
    return true;
}

bool Flight::cancelSeat() {
    if (availableSeats >= totalSeats) return false;
    ++availableSeats;
    return true;
}

double Flight::getOccupancyPercent() const {
    return (static_cast<double>(totalSeats - availableSeats) / totalSeats) * 100.0;
}

std::ostream& operator<<(std::ostream& os, const Flight& f) {
    f.displayDetails();
    return os;
}
