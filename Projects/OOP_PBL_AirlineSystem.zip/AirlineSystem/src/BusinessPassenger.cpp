#include "BusinessPassenger.h"
#include "Utilities.h"
#include <iostream>
#include <sstream>

BusinessPassenger::BusinessPassenger(const std::string& passengerId,
                                      const std::string& name,
                                      const std::string& email,
                                      const std::string& phone)
    : Passenger(passengerId, name, email, phone)
{}

double BusinessPassenger::calculateRefund(double farePaid, int hoursBeforeDeparture) const {
    if (hoursBeforeDeparture > 24)
        return farePaid * 0.75; // 75% refund if > 24 hours
    if (hoursBeforeDeparture > 12)
        return farePaid * 0.25; // 25% refund if 12-24 hours
    return 0.0;                 // No refund within 12 hours
}

void BusinessPassenger::displayDetails() const {
    printDivider();
    std::cout << "  [BUSINESS PASSENGER]\n";
    std::cout << "  ID       : " << passengerId << "\n";
    std::cout << "  Name     : " << name << "\n";
    std::cout << "  Email    : " << email << "\n";
    std::cout << "  Phone    : " << phone << "\n";
    std::cout << "  Baggage  : " << getBaggageAllowanceKg() << " kg\n";
    std::cout << "  Loyalty  : " << loyaltyPoints << " pts (2.0x multiplier)\n";
    printDivider();
}

std::string BusinessPassenger::serialize() const {
    std::ostringstream oss;
    oss << getType() << "|"
        << passengerId << "|"
        << name << "|"
        << email << "|"
        << phone << "|"
        << loyaltyPoints;
    return oss.str();
}
