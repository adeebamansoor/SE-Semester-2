#include "EconomyPassenger.h"
#include "Utilities.h"
#include <iostream>
#include <sstream>

EconomyPassenger::EconomyPassenger(const std::string& passengerId,
                                    const std::string& name,
                                    const std::string& email,
                                    const std::string& phone)
    : Passenger(passengerId, name, email, phone)
{}

double EconomyPassenger::calculateRefund(double farePaid, int hoursBeforeDeparture) const {
    // Economy: 50% refund if cancelling more than 48 hours before departure
    if (hoursBeforeDeparture > 48)
        return farePaid * 0.50;
    return 0.0; // No refund within 48 hours
}

void EconomyPassenger::displayDetails() const {
    printDivider();
    std::cout << "  [ECONOMY PASSENGER]\n";
    std::cout << "  ID       : " << passengerId << "\n";
    std::cout << "  Name     : " << name << "\n";
    std::cout << "  Email    : " << email << "\n";
    std::cout << "  Phone    : " << phone << "\n";
    std::cout << "  Baggage  : " << getBaggageAllowanceKg() << " kg\n";
    std::cout << "  Loyalty  : " << loyaltyPoints << " pts (1.0x multiplier)\n";
    printDivider();
}

std::string EconomyPassenger::serialize() const {
    // TYPE|id|name|email|phone|loyaltyPoints
    std::ostringstream oss;
    oss << getType() << "|"
        << passengerId << "|"
        << name << "|"
        << email << "|"
        << phone << "|"
        << loyaltyPoints;
    return oss.str();
}
