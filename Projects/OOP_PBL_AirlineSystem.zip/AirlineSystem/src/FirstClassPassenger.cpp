#include "FirstClassPassenger.h"
#include "Utilities.h"
#include <iostream>
#include <sstream>

FirstClassPassenger::FirstClassPassenger(const std::string& passengerId,
                                          const std::string& name,
                                          const std::string& email,
                                          const std::string& phone)
    : Passenger(passengerId, name, email, phone)
{}

double FirstClassPassenger::calculateRefund(double farePaid, int hoursBeforeDeparture) const {
    if (hoursBeforeDeparture > 12)
        return farePaid * 1.00; // Full refund if more than 12 hours before
    return farePaid * 0.50;     // 50% refund for last-minute cancellations
}

void FirstClassPassenger::displayDetails() const {
    printDivider();
    std::cout << "  [FIRST CLASS PASSENGER]\n";
    std::cout << "  ID       : " << passengerId << "\n";
    std::cout << "  Name     : " << name << "\n";
    std::cout << "  Email    : " << email << "\n";
    std::cout << "  Phone    : " << phone << "\n";
    std::cout << "  Baggage  : " << getBaggageAllowanceKg() << " kg\n";
    std::cout << "  Loyalty  : " << loyaltyPoints << " pts (3.0x multiplier)\n";
    printDivider();
}

std::string FirstClassPassenger::serialize() const {
    std::ostringstream oss;
    oss << getType() << "|"
        << passengerId << "|"
        << name << "|"
        << email << "|"
        << phone << "|"
        << loyaltyPoints;
    return oss.str();
}
