#include "Ticket.h"
#include "Utilities.h"
#include <iostream>
#include <sstream>

Ticket::Ticket(const std::string&         ticketId,
               std::shared_ptr<Passenger> passenger,
               std::shared_ptr<Flight>    flight,
               const std::string&         seatNumber,
               double                     farePaid)
    : ticketId(ticketId),
      passenger(std::move(passenger)),
      flight(std::move(flight)),
      seatNumber(seatNumber),
      farePaid(farePaid),
      bookingStatus("CONFIRMED")
{}

bool Ticket::operator==(const Ticket& other) const {
    return ticketId == other.ticketId;
}

std::ostream& operator<<(std::ostream& os, const Ticket& t) {
    printDivider();
    os << "  Ticket ID  : " << t.ticketId << "\n";
    os << "  Passenger  : " << t.passenger->getName()
       << " (" << t.passenger->getPassengerId() << ")\n";
    os << "  Flight     : " << t.flight->getFlightNumber()
       << "  " << t.flight->getOrigin() << " -> " << t.flight->getDestination() << "\n";
    os << "  Departure  : " << t.flight->getDepartureDateTime() << "\n";
    os << "  Seat       : " << t.seatNumber << "\n";
    os << "  Fare Paid  : " << formatCurrency(t.farePaid) << "\n";
    os << "  Status     : " << t.bookingStatus << "\n";
    printDivider();
    return os;
}

std::string Ticket::serialize() const {
    // ticketId|passengerId|flightNumber|seatNumber|farePaid|bookingStatus
    std::ostringstream oss;
    oss << ticketId << "|"
        << passenger->getPassengerId() << "|"
        << flight->getFlightNumber() << "|"
        << seatNumber << "|"
        << farePaid << "|"
        << bookingStatus;
    return oss.str();
}
