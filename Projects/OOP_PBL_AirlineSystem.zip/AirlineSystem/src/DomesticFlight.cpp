#include "DomesticFlight.h"
#include "Utilities.h"
#include <iostream>
#include <iomanip>
#include <sstream>

DomesticFlight::DomesticFlight(const std::string& flightNumber,
                                const std::string& origin,
                                const std::string& destination,
                                const std::string& departureDateTime,
                                int    totalSeats,
                                double distanceKm,
                                double pricePerKm)
    : Flight(flightNumber, origin, destination, departureDateTime, totalSeats),
      distanceKm(distanceKm),
      pricePerKm(pricePerKm)
{}

double DomesticFlight::calculateBaseFare() const {
    return distanceKm * pricePerKm;
}

void DomesticFlight::displayDetails() const {
    printDivider();
    std::cout << "  [DOMESTIC FLIGHT]\n";
    std::cout << "  Flight No : " << flightNumber << "\n";
    std::cout << "  Route     : " << origin << " -> " << destination << "\n";
    std::cout << "  Departure : " << departureDateTime << "\n";
    std::cout << "  Seats     : " << availableSeats << " / " << totalSeats << " available\n";
    std::cout << "  Distance  : " << distanceKm << " km\n";
    std::cout << "  Base Fare : " << formatCurrency(calculateBaseFare()) << "\n";
    printDivider();
}

std::string DomesticFlight::serialize() const {
    // Format: TYPE|flightNumber|origin|destination|departureDateTime|totalSeats|availableSeats|distanceKm|pricePerKm
    std::ostringstream oss;
    oss << getType() << "|"
        << flightNumber << "|"
        << origin << "|"
        << destination << "|"
        << departureDateTime << "|"
        << totalSeats << "|"
        << availableSeats << "|"
        << distanceKm << "|"
        << pricePerKm;
    return oss.str();
}
