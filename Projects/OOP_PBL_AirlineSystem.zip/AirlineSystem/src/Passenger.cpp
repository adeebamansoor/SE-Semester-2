#include "Passenger.h"

Passenger::Passenger(const std::string& passengerId,
                     const std::string& name,
                     const std::string& email,
                     const std::string& phone)
    : passengerId(passengerId),
      name(name),
      email(email),
      phone(phone),
      loyaltyPoints(0)
{}

std::ostream& operator<<(std::ostream& os, const Passenger& p) {
    p.displayDetails();
    return os;
}
