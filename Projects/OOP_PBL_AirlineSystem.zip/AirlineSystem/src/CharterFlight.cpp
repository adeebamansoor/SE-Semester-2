#include "CharterFlight.h"
#include "Utilities.h"
#include <iostream>
#include <sstream>
#include <stdexcept>

CharterFlight::CharterFlight(const std::string& flightNumber,
                              const std::string& origin,
                              const std::string& destination,
                              const std::string& departureDateTime,
                              int    totalSeats,
                              const std::string& contractHolder,
                              double totalCharterPrice)
    : Flight(flightNumber, origin, destination, departureDateTime, totalSeats),
      contractHolder(contractHolder),
      totalCharterPrice(totalCharterPrice)
{
    if (totalCharterPrice <= 0)
        throw std::invalid_argument("Charter price must be positive.");
}

double CharterFlight::calculateBaseFare() const {
    // Per-seat price = total charter price / number of seats
    return totalCharterPrice / static_cast<double>(totalSeats);
}

void CharterFlight::displayDetails() const {
    printDivider();
    std::cout << "  [CHARTER FLIGHT]\n";
    std::cout << "  Flight No       : " << flightNumber << "\n";
    std::cout << "  Route           : " << origin << " -> " << destination << "\n";
    std::cout << "  Departure       : " << departureDateTime << "\n";
    std::cout << "  Seats           : " << availableSeats << " / " << totalSeats << " available\n";
    std::cout << "  Contract Holder : " << contractHolder << "\n";
    std::cout << "  Charter Price   : " << formatCurrency(totalCharterPrice) << "\n";
    std::cout << "  Per-Seat Fare   : " << formatCurrency(calculateBaseFare()) << "\n";
    printDivider();
}

std::string CharterFlight::serialize() const {
    // TYPE|flightNumber|origin|destination|departureDateTime|totalSeats|availableSeats|contractHolder|totalCharterPrice
    std::ostringstream oss;
    oss << getType() << "|"
        << flightNumber << "|"
        << origin << "|"
        << destination << "|"
        << departureDateTime << "|"
        << totalSeats << "|"
        << availableSeats << "|"
        << contractHolder << "|"
        << totalCharterPrice;
    return oss.str();
}
