#include "Airline.h"
#include "Utilities.h"
#include "Exceptions.h"
#include "DomesticFlight.h"
#include "InternationalFlight.h"
#include "CharterFlight.h"
#include "EconomyPassenger.h"
#include "BusinessPassenger.h"
#include "FirstClassPassenger.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <iomanip>
#include <stdexcept>

// File paths for persistence
const std::string Airline::FLIGHTS_FILE    = "data/flights.txt";
const std::string Airline::PASSENGERS_FILE = "data/passengers.txt";
const std::string Airline::TICKETS_FILE    = "data/tickets.txt";

Airline::Airline(const std::string& airlineName)
    : airlineName(airlineName), nextTicketId(1000)
{}

// ======================== HELPERS ========================

std::string Airline::generateSeatNumber(int seatIndex) const {
    // Row A=1, B=2 … seats 1-6 per row
    char row    = 'A' + static_cast<char>((seatIndex / 6) % 26);
    int  col    = (seatIndex % 6) + 1;
    return std::string(1, row) + std::to_string(col);
}

void Airline::updateRevenueMap(const std::string& flightNumber, double amount, bool subtract) {
    if (subtract)
        revenueMap[flightNumber] -= amount;
    else
        revenueMap[flightNumber] += amount;
}

// ======================== FLIGHT MANAGEMENT ========================

void Airline::addFlight(std::shared_ptr<Flight> flight) {
    // Check for duplicate flight numbers
    auto it = std::find_if(flights.begin(), flights.end(),
        [&](const std::shared_ptr<Flight>& f) {
            return f->getFlightNumber() == flight->getFlightNumber();
        });
    if (it != flights.end()) {
        std::cout << "  [ERROR] Flight " << flight->getFlightNumber() << " already exists.\n";
        return;
    }
    flights.push_back(std::move(flight));
    std::cout << "  [OK] Flight added successfully.\n";
}

bool Airline::removeFlight(const std::string& flightNumber) {
    auto it = std::find_if(flights.begin(), flights.end(),
        [&](const std::shared_ptr<Flight>& f) {
            return f->getFlightNumber() == flightNumber;
        });
    if (it == flights.end()) return false;
    flights.erase(it);
    return true;
}

std::shared_ptr<Flight> Airline::searchFlightByNumber(const std::string& flightNumber) const {
    auto it = std::find_if(flights.begin(), flights.end(),
        [&](const std::shared_ptr<Flight>& f) {
            return f->getFlightNumber() == flightNumber;
        });
    return (it != flights.end()) ? *it : nullptr;
}

std::vector<Flight*> Airline::searchFlightsByRoute(const std::string& origin,
                                                     const std::string& destination) const {
    // Uses the generic template utility from Utilities.h
    return searchByPredicate<Flight>(flights, [&](const Flight& f) {
        return f.getOrigin() == origin && f.getDestination() == destination;
    });
}

std::vector<Flight*> Airline::searchFlightsByDate(const std::string& date) const {
    return searchByPredicate<Flight>(flights, [&](const Flight& f) {
        // departureDateTime starts with "YYYY-MM-DD"
        return f.getDepartureDateTime().substr(0, 10) == date;
    });
}

void Airline::listAllFlights() const {
    if (flights.empty()) {
        std::cout << "  No flights in the system.\n";
        return;
    }
    for (const auto& f : flights) {
        f->displayDetails();
    }
}

// ======================== PASSENGER MANAGEMENT ========================

void Airline::addPassenger(std::shared_ptr<Passenger> passenger) {
    auto it = std::find_if(passengers.begin(), passengers.end(),
        [&](const std::shared_ptr<Passenger>& p) {
            return p->getPassengerId() == passenger->getPassengerId();
        });
    if (it != passengers.end()) {
        std::cout << "  [ERROR] Passenger ID " << passenger->getPassengerId() << " already exists.\n";
        return;
    }
    passengers.push_back(std::move(passenger));
    std::cout << "  [OK] Passenger registered successfully.\n";
}

bool Airline::removePassenger(const std::string& passengerId) {
    auto it = std::find_if(passengers.begin(), passengers.end(),
        [&](const std::shared_ptr<Passenger>& p) {
            return p->getPassengerId() == passengerId;
        });
    if (it == passengers.end()) return false;
    passengers.erase(it);
    return true;
}

std::shared_ptr<Passenger> Airline::searchPassengerById(const std::string& passengerId) const {
    auto it = std::find_if(passengers.begin(), passengers.end(),
        [&](const std::shared_ptr<Passenger>& p) {
            return p->getPassengerId() == passengerId;
        });
    return (it != passengers.end()) ? *it : nullptr;
}

void Airline::listAllPassengers() const {
    if (passengers.empty()) {
        std::cout << "  No registered passengers.\n";
        return;
    }
    for (const auto& p : passengers) {
        p->displayDetails();
    }
}

void Airline::showBookingHistory(const std::string& passengerId) const {
    bool found = false;
    for (const auto& t : tickets) {
        if (t->getPassenger()->getPassengerId() == passengerId) {
            std::cout << *t;
            found = true;
        }
    }
    if (!found) std::cout << "  No bookings found for passenger " << passengerId << ".\n";
}

// ======================== BOOKING & CANCELLATION ========================

std::shared_ptr<Ticket> Airline::bookTicket(const std::string& passengerId,
                                              const std::string& flightNumber)
{
    // Look up passenger
    auto pax = searchPassengerById(passengerId);
    if (!pax) throw std::invalid_argument("Passenger not found: " + passengerId);

    // Look up flight
    auto flt = searchFlightByNumber(flightNumber);
    if (!flt) throw std::invalid_argument("Flight not found: " + flightNumber);

    // Reject if flight is full
    if (flt->getAvailableSeats() <= 0)
        throw FlightFullException(flightNumber);

    // Reject duplicate booking (same passenger, same flight, CONFIRMED)
    auto dup = std::find_if(tickets.begin(), tickets.end(),
        [&](const std::shared_ptr<Ticket>& t) {
            return t->getPassenger()->getPassengerId() == passengerId &&
                   t->getFlight()->getFlightNumber()   == flightNumber &&
                   t->getBookingStatus()               == "CONFIRMED";
        });
    if (dup != tickets.end())
        throw DuplicateBookingException(passengerId, flightNumber);

    // Determine seat number (based on booked seats count)
    int seatIndex = flt->getTotalSeats() - flt->getAvailableSeats();
    std::string seat = generateSeatNumber(seatIndex);

    // Calculate fare: base fare × loyalty multiplier
    double fare = flt->calculateBaseFare() * pax->getLoyaltyMultiplier();

    // Reserve seat
    flt->bookSeat();

    // Create ticket
    std::string id = "TKT" + std::to_string(nextTicketId++);
    auto ticket = std::make_shared<Ticket>(id, pax, flt, seat, fare);
    tickets.push_back(ticket);

    // Update revenue map
    updateRevenueMap(flightNumber, fare);

    // Add loyalty points (1 per 100 PKR, scaled by multiplier)
    int pts = static_cast<int>(fare / 100.0 * pax->getLoyaltyMultiplier());
    pax->addLoyaltyPoints(pts);

    std::cout << "\n  [OK] Booking confirmed!\n";
    std::cout << *ticket;
    return ticket;
}

double Airline::cancelTicket(const std::string& ticketId, int hoursBeforeDeparture) {
    auto it = std::find_if(tickets.begin(), tickets.end(),
        [&](const std::shared_ptr<Ticket>& t) {
            return t->getTicketId() == ticketId;
        });

    if (it == tickets.end())
        throw InvalidCancellationException("Ticket " + ticketId + " not found.");

    auto& ticket = *it;
    if (ticket->getBookingStatus() == "CANCELLED")
        throw InvalidCancellationException("Ticket " + ticketId + " is already cancelled.");

    // Polymorphic refund calculation — calls the correct subclass method
    double refund = ticket->getPassenger()->calculateRefund(
        ticket->getFarePaid(), hoursBeforeDeparture);

    // Free the seat back on the flight
    ticket->getFlight()->cancelSeat();
    ticket->cancel();

    // Adjust revenue
    updateRevenueMap(ticket->getFlight()->getFlightNumber(),
                     ticket->getFarePaid() - refund, false);

    return refund;
}

// ======================== REPORTS ========================

void Airline::reportTodaysDepartures(const std::string& today) const {
    printHeader("TODAY'S DEPARTURES — " + today);
    auto departures = searchFlightsByDate(today);
    if (departures.empty()) {
        std::cout << "  No flights departing today.\n";
        return;
    }
    for (auto* f : departures) {
        f->displayDetails();
    }
}

void Airline::reportOccupancyPerFlight() const {
    printHeader("FLIGHT OCCUPANCY REPORT");
    if (flights.empty()) { std::cout << "  No flights.\n"; return; }

    // Sort a copy by occupancy descending using STL sort
    std::vector<std::shared_ptr<Flight>> sorted = flights;
    std::sort(sorted.begin(), sorted.end(),
        [](const std::shared_ptr<Flight>& a, const std::shared_ptr<Flight>& b) {
            return a->getOccupancyPercent() > b->getOccupancyPercent();
        });

    std::cout << std::left
              << std::setw(12) << "Flight"
              << std::setw(15) << "Route"
              << std::setw(10) << "Booked"
              << std::setw(10) << "Total"
              << "Occupancy\n";
    printDivider();
    for (const auto& f : sorted) {
        int booked = f->getTotalSeats() - f->getAvailableSeats();
        std::cout << std::left
                  << std::setw(12) << f->getFlightNumber()
                  << std::setw(15) << (f->getOrigin() + "->" + f->getDestination())
                  << std::setw(10) << booked
                  << std::setw(10) << f->getTotalSeats()
                  << std::fixed << std::setprecision(1)
                  << f->getOccupancyPercent() << "%\n";
    }
}

void Airline::reportTop5RevenueFlights() const {
    printHeader("TOP 5 HIGHEST-REVENUE FLIGHTS");
    if (revenueMap.empty()) { std::cout << "  No revenue data.\n"; return; }

    // Copy map entries to a vector so we can sort
    std::vector<std::pair<std::string, double>> rev(revenueMap.begin(), revenueMap.end());
    std::sort(rev.begin(), rev.end(),
        [](const auto& a, const auto& b) { return a.second > b.second; });

    int count = 0;
    for (const auto& [fltNum, revenue] : rev) {
        if (count++ >= 5) break;
        std::cout << "  " << std::setw(3) << count << ". "
                  << std::setw(12) << fltNum
                  << "  Revenue: " << formatCurrency(revenue) << "\n";
    }
}

// ======================== PERSISTENCE ========================

void Airline::saveToFile() const {
    // Save flights
    std::ofstream fout(FLIGHTS_FILE);
    if (!fout) throw FileIOException(FLIGHTS_FILE);
    for (const auto& f : flights) {
        fout << f->serialize() << "\n";
    }
    fout.close();

    // Save passengers
    std::ofstream pout(PASSENGERS_FILE);
    if (!pout) throw FileIOException(PASSENGERS_FILE);
    for (const auto& p : passengers) {
        pout << p->serialize() << "\n";
    }
    pout.close();

    // Save tickets (ticketId counter too)
    std::ofstream tout(TICKETS_FILE);
    if (!tout) throw FileIOException(TICKETS_FILE);
    tout << nextTicketId << "\n"; // First line: next ID
    for (const auto& t : tickets) {
        tout << t->serialize() << "\n";
    }
    tout.close();

    std::cout << "  [OK] State saved to files.\n";
}

void Airline::loadFromFile() {
    // ---- Load flights ----
    std::ifstream fin(FLIGHTS_FILE);
    if (fin.is_open()) {
        std::string line;
        while (std::getline(fin, line)) {
            if (line.empty()) continue;
            std::istringstream ss(line);
            std::string token;
            std::vector<std::string> fields;
            while (std::getline(ss, token, '|')) fields.push_back(token);

            if (fields.empty()) continue;
            std::string type = fields[0];

            try {
                if (type == "DOMESTIC" && fields.size() >= 9) {
                    auto f = std::make_shared<DomesticFlight>(
                        fields[1], fields[2], fields[3], fields[4],
                        std::stoi(fields[5]),
                        std::stod(fields[7]), std::stod(fields[8]));
                    f->setAvailableSeats(std::stoi(fields[6]));
                    flights.push_back(f);
                }
                else if (type == "INTERNATIONAL" && fields.size() >= 11) {
                    auto f = std::make_shared<InternationalFlight>(
                        fields[1], fields[2], fields[3], fields[4],
                        std::stoi(fields[5]),
                        std::stod(fields[7]),
                        static_cast<bool>(std::stoi(fields[8])),
                        std::stod(fields[9]), std::stod(fields[10]));
                    f->setAvailableSeats(std::stoi(fields[6]));
                    flights.push_back(f);
                }
                else if (type == "CHARTER" && fields.size() >= 9) {
                    auto f = std::make_shared<CharterFlight>(
                        fields[1], fields[2], fields[3], fields[4],
                        std::stoi(fields[5]),
                        fields[7], std::stod(fields[8]));
                    f->setAvailableSeats(std::stoi(fields[6]));
                    flights.push_back(f);
                }
            } catch (...) {
                std::cerr << "  [WARN] Skipping malformed flight record.\n";
            }
        }
    }

    // ---- Load passengers ----
    std::ifstream pin(PASSENGERS_FILE);
    if (pin.is_open()) {
        std::string line;
        while (std::getline(pin, line)) {
            if (line.empty()) continue;
            std::istringstream ss(line);
            std::string token;
            std::vector<std::string> fields;
            while (std::getline(ss, token, '|')) fields.push_back(token);
            if (fields.size() < 6) continue;

            std::string type = fields[0];
            std::shared_ptr<Passenger> p;
            try {
                if (type == "ECONOMY")
                    p = std::make_shared<EconomyPassenger>(fields[1], fields[2], fields[3], fields[4]);
                else if (type == "BUSINESS")
                    p = std::make_shared<BusinessPassenger>(fields[1], fields[2], fields[3], fields[4]);
                else if (type == "FIRSTCLASS")
                    p = std::make_shared<FirstClassPassenger>(fields[1], fields[2], fields[3], fields[4]);
                if (p) {
                    p->setLoyaltyPoints(std::stoi(fields[5]));
                    passengers.push_back(p);
                }
            } catch (...) {
                std::cerr << "  [WARN] Skipping malformed passenger record.\n";
            }
        }
    }

    // ---- Load tickets ----
    std::ifstream tin(TICKETS_FILE);
    if (tin.is_open()) {
        std::string line;
        // First line: next ticket ID
        if (std::getline(tin, line)) {
            try { nextTicketId = std::stoi(line); } catch (...) {}
        }
        while (std::getline(tin, line)) {
            if (line.empty()) continue;
            std::istringstream ss(line);
            std::string token;
            std::vector<std::string> fields;
            while (std::getline(ss, token, '|')) fields.push_back(token);
            if (fields.size() < 6) continue;

            // fields: ticketId|passengerId|flightNumber|seatNumber|farePaid|bookingStatus
            auto pax = searchPassengerById(fields[1]);
            auto flt = searchFlightByNumber(fields[2]);
            if (!pax || !flt) continue;

            try {
                double fare = std::stod(fields[4]);
                auto t = std::make_shared<Ticket>(fields[0], pax, flt, fields[3], fare);
                t->setBookingStatus(fields[5]);
                tickets.push_back(t);
                // Rebuild revenue map
                if (fields[5] == "CONFIRMED") {
                    updateRevenueMap(fields[2], fare);
                }
            } catch (...) {
                std::cerr << "  [WARN] Skipping malformed ticket record.\n";
            }
        }
    }
}

void Airline::displayMenu() const {
    printHeader("SKYLINK AIRWAYS — MAIN MENU");
    std::cout << "\n  --- FLIGHTS ---\n";
    std::cout << "   1. Add Flight\n";
    std::cout << "   2. Remove Flight\n";
    std::cout << "   3. Search Flight by Number\n";
    std::cout << "   4. Search Flights by Route\n";
    std::cout << "   5. Search Flights by Date\n";
    std::cout << "   6. List All Flights\n";
    std::cout << "\n  --- PASSENGERS ---\n";
    std::cout << "   7. Register Passenger\n";
    std::cout << "   8. Remove Passenger\n";
    std::cout << "   9. View Passenger Details\n";
    std::cout << "  10. View Booking History\n";
    std::cout << "  11. List All Passengers\n";
    std::cout << "\n  --- BOOKINGS ---\n";
    std::cout << "  12. Book Ticket\n";
    std::cout << "  13. Cancel Ticket\n";
    std::cout << "\n  --- REPORTS ---\n";
    std::cout << "  14. Today's Departures\n";
    std::cout << "  15. Occupancy Report\n";
    std::cout << "  16. Top 5 Revenue Flights\n";
    std::cout << "\n  --- SYSTEM ---\n";
    std::cout << "  17. Save & Exit\n";
    std::cout << "\n  Choice: ";
}
