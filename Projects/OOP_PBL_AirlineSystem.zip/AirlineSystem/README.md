# SkyLink Airways — Airline Reservation & Flight Management System
### OOP (C++) Individual Assignment

---

## Project Structure

```
AirlineSystem/
├── include/
│   ├── Flight.h
│   ├── DomesticFlight.h
│   ├── InternationalFlight.h
│   ├── CharterFlight.h
│   ├── Passenger.h
│   ├── EconomyPassenger.h
│   ├── BusinessPassenger.h
│   ├── FirstClassPassenger.h
│   ├── Ticket.h
│   ├── Airline.h
│   ├── Exceptions.h
│   └── Utilities.h
├── src/
│   ├── Flight.cpp
│   ├── DomesticFlight.cpp
│   ├── InternationalFlight.cpp
│   ├── CharterFlight.cpp
│   ├── Passenger.cpp
│   ├── EconomyPassenger.cpp
│   ├── BusinessPassenger.cpp
│   ├── FirstClassPassenger.cpp
│   ├── Ticket.cpp
│   ├── Airline.cpp
│   └── main.cpp
├── data/
│   ├── flights.txt
│   ├── passengers.txt
│   └── tickets.txt
├── Makefile
└── README.md
```

---

## Build Instructions

### Prerequisites
- GCC with C++17 support (`g++ --version` should show 7.0+)
- GNU Make

### Build & Run
```bash
# Build
make

# Run
./airline

# Or build and run in one step
make run

# Clean compiled objects
make clean
```

### Manual Compilation (without Make)
```bash
mkdir -p obj data
g++ -std=c++17 -Wall -Wextra -Iinclude \
    src/Flight.cpp src/DomesticFlight.cpp src/InternationalFlight.cpp \
    src/CharterFlight.cpp src/Passenger.cpp src/EconomyPassenger.cpp \
    src/BusinessPassenger.cpp src/FirstClassPassenger.cpp \
    src/Ticket.cpp src/Airline.cpp src/main.cpp -o airline
./airline
```

---

## Sample Data

The `data/` folder contains pre-loaded sample data:
- **10 flights**: 4 Domestic, 4 International, 2 Charter
- **8 passengers**: 3 Economy, 3 Business, 2 First Class

The program loads this data automatically on startup.

---

## Menu Options

| Option | Action |
|--------|--------|
| 1  | Add a new flight (Domestic / International / Charter) |
| 2  | Remove a flight by number |
| 3  | Search flight by number |
| 4  | Search flights by route (origin + destination) |
| 5  | Search flights by date |
| 6  | List all flights |
| 7  | Register a new passenger |
| 8  | Remove a passenger |
| 9  | View passenger details |
| 10 | View passenger booking history |
| 11 | List all passengers |
| 12 | Book a ticket |
| 13 | Cancel a ticket (polymorphic refund) |
| 14 | Today's departures report |
| 15 | Occupancy percentage per flight |
| 16 | Top 5 highest-revenue flights |
| 17 | Save state and exit |

---

## OOP Features Demonstrated

- **Abstraction**: `Flight` and `Passenger` are abstract base classes with pure virtual functions.
- **Inheritance**: 3 flight types, 3 passenger types.
- **Polymorphism**: `calculateBaseFare()`, `calculateRefund()`, `displayDetails()` are virtual — resolved at runtime.
- **Operator Overloading**: `operator<<` (Flight, Passenger, Ticket), `operator==` (Ticket).
- **Templates**: `searchByPredicate<T>()` in `Utilities.h` — generic search over any `shared_ptr<T>` container.
- **Exceptions**: `FlightFullException`, `InvalidCancellationException`, `DuplicateBookingException`.
- **STL**: `vector`, `map`, `find_if`, `sort`.
- **Smart Pointers**: `shared_ptr` throughout — no raw `new`/`delete`.
- **File Persistence**: Pipe-delimited text files; full round-trip save/load.

---

## AI Assistance Disclosure
Concept clarification and code structure were developed with AI assistance. All submitted code was understood and verified by the student.
