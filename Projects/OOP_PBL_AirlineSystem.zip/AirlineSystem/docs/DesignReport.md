# Design Report
## SkyLink Airways — Airline Reservation & Flight Management System
### OOP (C++) Individual Assignment

---

## 1. Introduction

This report documents the design decisions made in implementing the SkyLink Airways Reservation and Flight Management System in C++17. The system models a real-world airline domain and demonstrates all four pillars of object-oriented programming: encapsulation, abstraction, inheritance, and polymorphism. Each design choice is justified below.

---

## 2. Encapsulation

All data members across every class are declared `private` or `protected`. Access is provided exclusively through well-named getter and setter methods. For example, `Flight::availableSeats` is private and can only be changed through `bookSeat()` and `cancelSeat()` — methods that enforce business rules (seats cannot go below 0 or above total). This prevents external code from corrupting the flight state directly.

The `Ticket` class demonstrates tight encapsulation by holding `shared_ptr` members for both `Passenger` and `Flight`. The ticket's `bookingStatus` can only be changed via the `cancel()` method, not through a raw setter, ensuring a cancelled ticket can never be "un-cancelled" without explicit system logic.

---

## 3. Abstraction

Two abstract base classes define the contracts for the system:

**`Flight`** declares `calculateBaseFare()` and `displayDetails()` as pure virtual functions. Any code that works with a `Flight*` or `shared_ptr<Flight>` can call these methods without knowing whether the object is a `DomesticFlight`, `InternationalFlight`, or `CharterFlight`. The Airline class stores `vector<shared_ptr<Flight>>` and calls `calculateBaseFare()` polymorphically at booking time.

**`Passenger`** declares `calculateRefund()`, `getBaggageAllowanceKg()`, `getLoyaltyMultiplier()`, and `getRefundPercentage()` as pure virtual. This forces every concrete passenger subclass to define its own refund policy, which is the core business requirement.

---

## 4. Inheritance

### Flight Hierarchy

| Class | Additional Attributes | Pricing Logic |
|---|---|---|
| `DomesticFlight` | `distanceKm`, `pricePerKm` | `distance × rate` |
| `InternationalFlight` | `visaRequired`, `fuelSurcharge` | `(distance × rate) + surcharge` |
| `CharterFlight` | `contractHolder`, `totalCharterPrice` | `charterPrice / seats` |

Each subclass overrides the pure virtual functions and adds attributes unique to that flight type. Storing them as `shared_ptr<Flight>` lets the Airline class manage all flight types uniformly.

### Passenger Hierarchy

| Class | Baggage | Loyalty Multiplier | Refund Policy |
|---|---|---|---|
| `EconomyPassenger` | 20 kg | 1.0× | 50% if > 48 hrs, else 0% |
| `BusinessPassenger` | 40 kg | 2.0× | 75% if > 24 hrs, 25% if 12–24 hrs, else 0% |
| `FirstClassPassenger` | 60 kg | 3.0× | 100% if > 12 hrs, else 50% |

The loyalty multiplier also affects the fare paid: a First Class passenger pays 3× the base fare and earns 3× the loyalty points.

---

## 5. Polymorphism

Polymorphism is demonstrated in three ways:

**Fare calculation**: `Airline::bookTicket()` calls `flight->calculateBaseFare()` through a `shared_ptr<Flight>`. At runtime, the virtual dispatch mechanism calls `DomesticFlight::calculateBaseFare()`, `InternationalFlight::calculateBaseFare()`, or `CharterFlight::calculateBaseFare()` depending on the actual object.

**Refund calculation**: `Airline::cancelTicket()` calls `ticket->getPassenger()->calculateRefund(farePaid, hours)`. The correct subclass override (`EconomyPassenger`, `BusinessPassenger`, or `FirstClassPassenger`) is selected at runtime — the Airline class has no `if/else` for passenger types.

**Display**: `operator<<` for `Flight` and `Passenger` calls `displayDetails()` virtually, so `std::cout << *flightPtr` prints the correct subclass output.

---

## 6. Operator Overloading

`operator<<` is overloaded as a `friend` function for `Flight`, `Passenger`, and `Ticket`. This allows natural stream insertion syntax (`std::cout << ticket`) in client code. For `Flight` and `Passenger`, the overload delegates to the virtual `displayDetails()` method, so polymorphism and the stream operator work together seamlessly.

`operator==` is overloaded in `Ticket` to compare by `ticketId`. This enables STL algorithms like `std::find` to locate tickets by ID directly, rather than requiring a manual comparator every time.

---

## 7. Function Templates

`searchByPredicate<T>()` in `Utilities.h` is a function template that accepts a `vector<shared_ptr<T>>` and a `std::function<bool(const T&)>` predicate. It returns a `vector<T*>` of matching elements. The Airline class uses this for `searchFlightsByRoute()` and `searchFlightsByDate()` — the same template works for flights and, if needed, for passengers. This avoids code duplication and demonstrates genuine generic programming.

---

## 8. Exception Handling

Four custom exception classes inherit from `std::runtime_error`:

- **`FlightFullException`**: Thrown in `bookTicket()` when `availableSeats <= 0`.
- **`InvalidCancellationException`**: Thrown in `cancelTicket()` when the ticket is not found or already cancelled.
- **`DuplicateBookingException`**: Thrown when the same passenger attempts to book the same flight twice.
- **`FileIOException`**: Thrown when a persistence file cannot be opened.

Each exception carries a descriptive message. In `main.cpp`, the menu loop catches these exceptions specifically and prints user-friendly messages without crashing the program. The `loadFromFile()` method also catches exceptions per-record and skips malformed lines rather than aborting the entire load.

---

## 9. STL Usage

- **`std::vector`**: Used for all collections (`flights`, `passengers`, `tickets`).
- **`std::map`**: Used in `revenueMap` (`map<string, double>`) to track total revenue per flight number. A `map` was chosen over `unordered_map` for deterministic iteration order in reports.
- **`std::find_if`**: Used extensively to search collections by predicate (e.g., find flight by number, detect duplicate bookings).
- **`std::sort`**: Used in `reportOccupancyPerFlight()` and `reportTop5RevenueFlights()` to sort results before display.

---

## 10. File Persistence

State is saved to three pipe-delimited text files in the `data/` directory:

- `flights.txt`: Each line begins with a type tag (`DOMESTIC`, `INTERNATIONAL`, `CHARTER`) followed by all attributes.
- `passengers.txt`: Each line begins with a class tag followed by attributes.
- `tickets.txt`: First line is the next ticket ID counter; subsequent lines are ticket records referencing passengers and flights by ID.

On load, the type tag is read first, the appropriate `make_shared<DerivedClass>()` call is made, and the remaining fields are parsed. Malformed lines are skipped with a warning. This ensures the program starts gracefully even if a data file is partially corrupted.

---

## 11. Memory Safety

`std::shared_ptr` is used throughout. The Airline class owns `vector<shared_ptr<Flight>>`, `vector<shared_ptr<Passenger>>`, and `vector<shared_ptr<Ticket>>`. The Ticket class also holds `shared_ptr<Passenger>` and `shared_ptr<Flight>`, so the same underlying objects are reference-counted rather than duplicated. There is no raw `new` or `delete` anywhere in the codebase. Memory is automatically released when the Airline object goes out of scope at program exit.

---

## 12. Known Limitations

- Departure time is stored as a plain string rather than a proper `std::tm` or `std::chrono` object; date comparisons are string-based substring matches.
- The system does not implement seat-map visualization; seat numbers are auto-generated from a simple row/column formula.
- The refund's "hours before departure" is provided by the user at cancellation time rather than computed from the current system clock and the stored departure time.

---

## 13. Test Cases

| Test | Input | Expected Result | Status |
|---|---|---|---|
| Book a valid ticket | P001 on SK101 | TKT1000 confirmed, seat A1 | PASS |
| Duplicate booking | P001 on SK101 again | `DuplicateBookingException` message | PASS |
| Invalid passenger | P099 on SK101 | "Passenger not found" error | PASS |
| Invalid flight | P001 on SK999 | "Flight not found" error | PASS |
| Economy refund > 48 hrs | P001 cancel with 72 hrs | 50% of fare returned | PASS |
| Economy refund < 48 hrs | P001 cancel with 24 hrs | 0% refund | PASS |
| First class refund | P005 cancel with 20 hrs | 100% refund | PASS |
| Save & reload | Exit then restart | All flights and passengers reload | PASS |
| Occupancy report | After bookings | Sorted descending by % | PASS |
| Top 5 revenue report | After bookings | Sorted descending by revenue | PASS |
