```mermaid
classDiagram

%% ======================== FLIGHT HIERARCHY ========================
class Flight {
    <<abstract>>
    #flightNumber : string
    #origin : string
    #destination : string
    #departureDateTime : string
    #totalSeats : int
    #availableSeats : int
    +Flight(flightNumber, origin, destination, departureDateTime, totalSeats)
    +calculateBaseFare()* double
    +displayDetails()* void
    +getType()* string
    +serialize()* string
    +bookSeat() bool
    +cancelSeat() bool
    +getOccupancyPercent() double
    +getFlightNumber() string
    +getOrigin() string
    +getDestination() string
    +getDepartureDateTime() string
    +getTotalSeats() int
    +getAvailableSeats() int
    +operator<<(ostream, Flight)
}

class DomesticFlight {
    -distanceKm : double
    -pricePerKm : double
    +DomesticFlight(...)
    +calculateBaseFare() double
    +displayDetails() void
    +getType() string
    +serialize() string
}

class InternationalFlight {
    -visaRequired : bool
    -fuelSurcharge : double
    -distanceKm : double
    -pricePerKm : double
    +InternationalFlight(...)
    +calculateBaseFare() double
    +displayDetails() void
    +getType() string
    +serialize() string
    +isVisaRequired() bool
}

class CharterFlight {
    -contractHolder : string
    -totalCharterPrice : double
    +CharterFlight(...)
    +calculateBaseFare() double
    +displayDetails() void
    +getType() string
    +serialize() string
    +getContractHolder() string
}

Flight <|-- DomesticFlight
Flight <|-- InternationalFlight
Flight <|-- CharterFlight

%% ======================== PASSENGER HIERARCHY ========================
class Passenger {
    <<abstract>>
    #passengerId : string
    #name : string
    #email : string
    #phone : string
    #loyaltyPoints : int
    +Passenger(...)
    +calculateRefund(farePaid, hoursBeforeDeparture)* double
    +displayDetails()* void
    +getType()* string
    +serialize()* string
    +getBaggageAllowanceKg()* double
    +getLoyaltyMultiplier()* double
    +getRefundPercentage()* double
    +addLoyaltyPoints(pts) void
    +getPassengerId() string
    +getName() string
    +operator<<(ostream, Passenger)
}

class EconomyPassenger {
    +calculateRefund(farePaid, hours) double
    +displayDetails() void
    +getBaggageAllowanceKg() double
    +getLoyaltyMultiplier() double
    +getRefundPercentage() double
    +serialize() string
}

class BusinessPassenger {
    +calculateRefund(farePaid, hours) double
    +displayDetails() void
    +getBaggageAllowanceKg() double
    +getLoyaltyMultiplier() double
    +getRefundPercentage() double
    +serialize() string
}

class FirstClassPassenger {
    +calculateRefund(farePaid, hours) double
    +displayDetails() void
    +getBaggageAllowanceKg() double
    +getLoyaltyMultiplier() double
    +getRefundPercentage() double
    +serialize() string
}

Passenger <|-- EconomyPassenger
Passenger <|-- BusinessPassenger
Passenger <|-- FirstClassPassenger

%% ======================== TICKET ========================
class Ticket {
    -ticketId : string
    -passenger : shared_ptr~Passenger~
    -flight : shared_ptr~Flight~
    -seatNumber : string
    -farePaid : double
    -bookingStatus : string
    +Ticket(...)
    +cancel() void
    +serialize() string
    +getTicketId() string
    +getFarePaid() double
    +getBookingStatus() string
    +operator==(Ticket) bool
    +operator<<(ostream, Ticket)
}

Ticket "1" --> "1" Passenger : references
Ticket "1" --> "1" Flight    : references

%% ======================== AIRLINE ========================
class Airline {
    -airlineName : string
    -flights : vector~shared_ptr~Flight~~
    -passengers : vector~shared_ptr~Passenger~~
    -tickets : vector~shared_ptr~Ticket~~
    -revenueMap : map~string,double~
    -nextTicketId : int
    +Airline(name)
    +addFlight(flight) void
    +removeFlight(flightNumber) bool
    +searchFlightByNumber(num) shared_ptr~Flight~
    +searchFlightsByRoute(orig,dest) vector
    +searchFlightsByDate(date) vector
    +listAllFlights() void
    +addPassenger(passenger) void
    +removePassenger(id) bool
    +searchPassengerById(id) shared_ptr~Passenger~
    +showBookingHistory(id) void
    +bookTicket(passId, flightNum) shared_ptr~Ticket~
    +cancelTicket(ticketId, hours) double
    +reportTodaysDepartures(date) void
    +reportOccupancyPerFlight() void
    +reportTop5RevenueFlights() void
    +saveToFile() void
    +loadFromFile() void
}

Airline "1" o-- "many" Flight     : aggregates
Airline "1" o-- "many" Passenger  : aggregates
Airline "1" o-- "many" Ticket     : aggregates

%% ======================== EXCEPTIONS ========================
class FlightFullException {
    +FlightFullException(flightNumber)
}

class InvalidCancellationException {
    +InvalidCancellationException(reason)
}

class DuplicateBookingException {
    +DuplicateBookingException(passId, flightNum)
}
```
