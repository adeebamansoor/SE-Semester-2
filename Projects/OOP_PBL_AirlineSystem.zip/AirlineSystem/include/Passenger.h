#ifndef PASSENGER_H
#define PASSENGER_H

#include <string>
#include <iostream>

// Abstract base class for all passenger types.
// Encapsulates shared passenger data and declares the polymorphic
// refund calculation interface.
class Passenger {
protected:
    std::string passengerId;
    std::string name;
    std::string email;
    std::string phone;
    int         loyaltyPoints;

public:
    Passenger(const std::string& passengerId,
              const std::string& name,
              const std::string& email,
              const std::string& phone);

    virtual ~Passenger() = default;

    // Pure virtual: each subclass defines its own refund rules
    virtual double calculateRefund(double farePaid, int hoursBeforeDeparture) const = 0;
    virtual void   displayDetails() const = 0;
    virtual std::string getType()   const = 0;
    virtual std::string serialize() const = 0;

    // Loyalty points & class-specific multipliers
    virtual double getBaggageAllowanceKg() const = 0;
    virtual double getLoyaltyMultiplier()  const = 0;
    virtual double getRefundPercentage()   const = 0;

    void addLoyaltyPoints(int pts) { loyaltyPoints += pts; }

    // Getters
    std::string getPassengerId() const { return passengerId; }
    std::string getName()        const { return name; }
    std::string getEmail()       const { return email; }
    std::string getPhone()       const { return phone; }
    int         getLoyaltyPoints()const{ return loyaltyPoints; }

    // Setters
    void setLoyaltyPoints(int pts) { loyaltyPoints = pts; }

    // Operator overload: stream insertion
    friend std::ostream& operator<<(std::ostream& os, const Passenger& p);
};

#endif // PASSENGER_H
