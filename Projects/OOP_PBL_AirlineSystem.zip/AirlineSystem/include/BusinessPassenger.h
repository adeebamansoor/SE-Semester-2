#ifndef BUSINESSPASSENGER_H
#define BUSINESSPASSENGER_H

#include "Passenger.h"

// Business class passengers:
// - 40 kg baggage allowance
// - 2.0x loyalty multiplier
// - Refund: 75% if > 24 hrs before departure, 25% if 12-24 hrs, 0% otherwise
class BusinessPassenger : public Passenger {
public:
    BusinessPassenger(const std::string& passengerId,
                      const std::string& name,
                      const std::string& email,
                      const std::string& phone);

    double      calculateRefund(double farePaid, int hoursBeforeDeparture) const override;
    void        displayDetails() const override;
    std::string getType()        const override { return "BUSINESS"; }
    std::string serialize()      const override;

    double getBaggageAllowanceKg() const override { return 40.0; }
    double getLoyaltyMultiplier()  const override { return 2.0; }
    double getRefundPercentage()   const override { return 75.0; }
};

#endif // BUSINESSPASSENGER_H
