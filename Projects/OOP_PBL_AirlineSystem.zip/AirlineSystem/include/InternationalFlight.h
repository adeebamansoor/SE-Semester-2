#ifndef INTERNATIONALFLIGHT_H
#define INTERNATIONALFLIGHT_H

#include "Flight.h"
#include <string>

// International flights cross country borders.
// Adds a visa requirement flag and a fuel surcharge to the fare.
class InternationalFlight : public Flight {
private:
    bool   visaRequired;
    double fuelSurcharge; // Fixed surcharge added on top of distance-based fare
    double distanceKm;
    double pricePerKm;

public:
    InternationalFlight(const std::string& flightNumber,
                        const std::string& origin,
                        const std::string& destination,
                        const std::string& departureDateTime,
                        int    totalSeats,
                        double distanceKm,
                        bool   visaRequired,
                        double fuelSurcharge = 5000.0,
                        double pricePerKm    = 12.0); // Higher international rate

    double      calculateBaseFare() const override;
    void        displayDetails()    const override;
    std::string getType()           const override { return "INTERNATIONAL"; }
    std::string serialize()         const override;

    // Getters
    bool   isVisaRequired()   const { return visaRequired; }
    double getFuelSurcharge() const { return fuelSurcharge; }
    double getDistanceKm()    const { return distanceKm; }
};

#endif // INTERNATIONALFLIGHT_H
