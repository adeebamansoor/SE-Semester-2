#ifndef EXCEPTIONS_H
#define EXCEPTIONS_H

#include <stdexcept>
#include <string>

// Custom exception for when a flight has no available seats
class FlightFullException : public std::runtime_error {
public:
    explicit FlightFullException(const std::string& flightNumber)
        : std::runtime_error("Flight " + flightNumber + " is fully booked. No seats available.") {}
};

// Custom exception for invalid cancellation attempts
class InvalidCancellationException : public std::runtime_error {
public:
    explicit InvalidCancellationException(const std::string& reason)
        : std::runtime_error("Invalid cancellation: " + reason) {}
};

// Custom exception for duplicate booking attempts
class DuplicateBookingException : public std::runtime_error {
public:
    explicit DuplicateBookingException(const std::string& passengerId, const std::string& flightNumber)
        : std::runtime_error("Passenger " + passengerId + " already has a booking on flight " + flightNumber) {}
};

// Custom exception for file I/O errors
class FileIOException : public std::runtime_error {
public:
    explicit FileIOException(const std::string& filename)
        : std::runtime_error("Failed to open file: " + filename) {}
};

#endif // EXCEPTIONS_H
