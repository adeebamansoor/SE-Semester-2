#ifndef DOMESTICFLIGHT_H
#define DOMESTICFLIGHT_H

#include "Flight.h"

// Domestic flights operate within the same country.
// Base fare is calculated per kilometre at a domestic rate.
class DomesticFlight : public Flight {
private:
    double distanceKm;     // Route distance in kilometres
    double pricePerKm;     // Domestic rate per km

public:
    DomesticFlight(const std::string& flightNumber,
                   const std::string& origin,
                   const std::string& destination,
                   const std::string& departureDateTime,
                   int    totalSeats,
                   double distanceKm,
                   double pricePerKm = 8.5); // Default domestic rate

    double      calculateBaseFare() const override;
    void        displayDetails()    const override;
    std::string getType()           const override { return "DOMESTIC"; }
    std::string serialize()         const override;

    // Getters
    double getDistanceKm() const { return distanceKm; }
    double getPricePerKm() const { return pricePerKm; }
};

#endif // DOMESTICFLIGHT_H
