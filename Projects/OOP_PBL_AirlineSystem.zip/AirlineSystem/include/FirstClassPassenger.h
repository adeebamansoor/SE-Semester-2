#ifndef FIRSTCLASSPASSENGER_H
#define FIRSTCLASSPASSENGER_H

#include "Passenger.h"

// First-class passengers:
// - 60 kg baggage allowance
// - 3.0x loyalty multiplier
// - Full refund if > 12 hrs before departure, 50% otherwise (no zero)
class FirstClassPassenger : public Passenger {
public:
    FirstClassPassenger(const std::string& passengerId,
                        const std::string& name,
                        const std::string& email,
                        const std::string& phone);

    double      calculateRefund(double farePaid, int hoursBeforeDeparture) const override;
    void        displayDetails() const override;
    std::string getType()        const override { return "FIRSTCLASS"; }
    std::string serialize()      const override;

    double getBaggageAllowanceKg() const override { return 60.0; }
    double getLoyaltyMultiplier()  const override { return 3.0; }
    double getRefundPercentage()   const override { return 100.0; }
};

#endif // FIRSTCLASSPASSENGER_H
