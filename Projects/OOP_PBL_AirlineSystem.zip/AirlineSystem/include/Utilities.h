#ifndef UTILITIES_H
#define UTILITIES_H

#include <vector>
#include <memory>
#include <functional>
#include <algorithm>
#include <string>
#include <iostream>
#include <iomanip>
#include <sstream>

// -----------------------------------------------------------------------
// Generic search utility — works for any container of shared_ptr<T>
// The predicate is a callable that takes a const T& and returns bool.
// Returns a vector of raw (non-owning) pointers to matching elements.
// -----------------------------------------------------------------------
template <typename T>
std::vector<T*> searchByPredicate(
    const std::vector<std::shared_ptr<T>>& container,
    std::function<bool(const T&)> predicate)
{
    std::vector<T*> results;
    for (const auto& item : container) {
        if (predicate(*item)) {
            results.push_back(item.get());
        }
    }
    return results;
}

// Overload for unique_ptr containers
template <typename T>
std::vector<T*> searchByPredicateUnique(
    const std::vector<std::unique_ptr<T>>& container,
    std::function<bool(const T&)> predicate)
{
    std::vector<T*> results;
    for (const auto& item : container) {
        if (predicate(*item)) {
            results.push_back(item.get());
        }
    }
    return results;
}

// Helper: print a horizontal divider
inline void printDivider(char ch = '-', int width = 60) {
    std::cout << std::string(width, ch) << '\n';
}

// Helper: print a section header
inline void printHeader(const std::string& title) {
    printDivider('=');
    std::cout << "  " << title << '\n';
    printDivider('=');
}

// Helper: trim whitespace from a string
inline std::string trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    size_t end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}

// Helper: format double to 2 decimal places
inline std::string formatCurrency(double amount) {
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(2) << amount;
    return "PKR " + oss.str();
}

#endif // UTILITIES_H
