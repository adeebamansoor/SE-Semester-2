#ifndef TICKET_H
#define TICKET_H

#include <string>
#include <memory>
#include <iostream>
#include "Passenger.h"
#include "Flight.h"

// Ticket links a Passenger to a Flight.
// Uses shared_ptr so that the same passenger and flight objects remain
// alive as long as any ticket references them.
class Ticket {
private:
    std::string ticketId;
    std::shared_ptr<Passenger> passenger;
    std::shared_ptr<Flight>    flight;
    std::string seatNumber;
    double      farePaid;
    std::string bookingStatus; // "CONFIRMED", "CANCELLED"

public:
    Ticket(const std::string&            ticketId,
           std::shared_ptr<Passenger>    passenger,
           std::shared_ptr<Flight>       flight,
           const std::string&            seatNumber,
           double                        farePaid);

    // Operator overloads
    bool operator==(const Ticket& other) const; // Compare by ticketId
    friend std::ostream& operator<<(std::ostream& os, const Ticket& t);

    // Actions
    void cancel() { bookingStatus = "CANCELLED"; }

    // Getters
    std::string getTicketId()     const { return ticketId; }
    std::string getSeatNumber()   const { return seatNumber; }
    double      getFarePaid()     const { return farePaid; }
    std::string getBookingStatus()const { return bookingStatus; }

    std::shared_ptr<Passenger> getPassenger() const { return passenger; }
    std::shared_ptr<Flight>    getFlight()    const { return flight; }

    // Setters for file reload
    void setBookingStatus(const std::string& s) { bookingStatus = s; }

    // Serialize to one line for file persistence
    std::string serialize() const;
};

#endif // TICKET_H
