#ifndef CHARTERFLIGHT_H
#define CHARTERFLIGHT_H

#include "Flight.h"
#include <string>

// Charter flights are privately contracted — the whole aircraft is booked.
// Fare is calculated as a flat charter price divided by seat count.
class CharterFlight : public Flight {
private:
    std::string contractHolder;   // Name of the company/person who chartered
    double      totalCharterPrice; // Fixed price for the entire aircraft

public:
    CharterFlight(const std::string& flightNumber,
                  const std::string& origin,
                  const std::string& destination,
                  const std::string& departureDateTime,
                  int    totalSeats,
                  const std::string& contractHolder,
                  double totalCharterPrice);

    double      calculateBaseFare() const override;
    void        displayDetails()    const override;
    std::string getType()           const override { return "CHARTER"; }
    std::string serialize()         const override;

    // Getters
    std::string getContractHolder()    const { return contractHolder; }
    double      getTotalCharterPrice() const { return totalCharterPrice; }
};

#endif // CHARTERFLIGHT_H
