#ifndef ECONOMYPASSENGER_H
#define ECONOMYPASSENGER_H

#include "Passenger.h"

// Economy class passengers:
// - 20 kg baggage allowance
// - 1.0x loyalty multiplier (base rate)
// - Refund: 50% if > 48 hrs before departure, 0% otherwise
class EconomyPassenger : public Passenger {
public:
    EconomyPassenger(const std::string& passengerId,
                     const std::string& name,
                     const std::string& email,
                     const std::string& phone);

    double      calculateRefund(double farePaid, int hoursBeforeDeparture) const override;
    void        displayDetails() const override;
    std::string getType()        const override { return "ECONOMY"; }
    std::string serialize()      const override;

    double getBaggageAllowanceKg() const override { return 20.0; }
    double getLoyaltyMultiplier()  const override { return 1.0; }
    double getRefundPercentage()   const override { return 50.0; }
};

#endif // ECONOMYPASSENGER_H
