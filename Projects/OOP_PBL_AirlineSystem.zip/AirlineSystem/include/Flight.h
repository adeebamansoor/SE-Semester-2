#ifndef FLIGHT_H
#define FLIGHT_H

#include <string>
#include <iostream>

// Abstract base class for all flight types.
// Enforces a common interface via pure virtual functions.
class Flight {
protected:
    std::string flightNumber;
    std::string origin;
    std::string destination;
    std::string departureDateTime; // Format: "YYYY-MM-DD HH:MM"
    int         totalSeats;
    int         availableSeats;

public:
    // Constructor
    Flight(const std::string& flightNumber,
           const std::string& origin,
           const std::string& destination,
           const std::string& departureDateTime,
           int totalSeats);

    // Virtual destructor — required for proper cleanup of derived objects
    virtual ~Flight() = default;

    // Pure virtual functions — every derived class MUST implement these
    virtual double calculateBaseFare() const = 0;
    virtual void   displayDetails()    const = 0;
    // Returns a type tag for file serialization
    virtual std::string getType()      const = 0;
    // Serialize to a single-line string for file persistence
    virtual std::string serialize()    const = 0;

    // Seat management
    bool bookSeat();      // Decrements availableSeats; returns false if full
    bool cancelSeat();    // Increments availableSeats

    // Getters
    std::string getFlightNumber()     const { return flightNumber; }
    std::string getOrigin()           const { return origin; }
    std::string getDestination()      const { return destination; }
    std::string getDepartureDateTime()const { return departureDateTime; }
    int         getTotalSeats()       const { return totalSeats; }
    int         getAvailableSeats()   const { return availableSeats; }
    double      getOccupancyPercent() const;

    // Setters
    void setAvailableSeats(int seats) { availableSeats = seats; }

    // Operator overload: stream insertion for any Flight (uses displayDetails)
    friend std::ostream& operator<<(std::ostream& os, const Flight& f);
};

#endif // FLIGHT_H
