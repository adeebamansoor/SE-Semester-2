#ifndef AIRLINE_H
#define AIRLINE_H

#include <vector>
#include <map>
#include <memory>
#include <string>
#include "Flight.h"
#include "Passenger.h"
#include "Ticket.h"

// Airline is the central aggregator class.
// It owns the collections of Flights, Passengers, and Tickets
// and exposes all high-level operations.
class Airline {
private:
    std::string airlineName;

    // Smart-pointer containers — no raw new/delete anywhere
    std::vector<std::shared_ptr<Flight>>    flights;
    std::vector<std::shared_ptr<Passenger>> passengers;
    std::vector<std::shared_ptr<Ticket>>    tickets;

    // Revenue map: flightNumber -> total revenue (for reports)
    std::map<std::string, double> revenueMap;

    int nextTicketId; // Auto-incremented ticket ID counter

    // ---- File paths ----
    static const std::string FLIGHTS_FILE;
    static const std::string PASSENGERS_FILE;
    static const std::string TICKETS_FILE;

    // ---- Internal helpers ----
    std::string generateSeatNumber(int seatIndex) const;
    void        updateRevenueMap(const std::string& flightNumber, double amount, bool subtract = false);

public:
    explicit Airline(const std::string& airlineName);

    // ===================== FLIGHT MANAGEMENT =====================
    void addFlight(std::shared_ptr<Flight> flight);
    bool removeFlight(const std::string& flightNumber);
    std::shared_ptr<Flight> searchFlightByNumber(const std::string& flightNumber) const;
    std::vector<Flight*> searchFlightsByRoute(const std::string& origin,
                                               const std::string& destination) const;
    std::vector<Flight*> searchFlightsByDate(const std::string& date) const;
    void listAllFlights() const;

    // ===================== PASSENGER MANAGEMENT =====================
    void addPassenger(std::shared_ptr<Passenger> passenger);
    bool removePassenger(const std::string& passengerId);
    std::shared_ptr<Passenger> searchPassengerById(const std::string& passengerId) const;
    void listAllPassengers() const;
    void showBookingHistory(const std::string& passengerId) const;

    // ===================== BOOKING & CANCELLATION =====================
    std::shared_ptr<Ticket> bookTicket(const std::string& passengerId,
                                        const std::string& flightNumber);
    double cancelTicket(const std::string& ticketId, int hoursBeforeDeparture);

    // ===================== REPORTS =====================
    void reportTodaysDepartures(const std::string& today) const;
    void reportOccupancyPerFlight() const;
    void reportTop5RevenueFlights() const;

    // ===================== PERSISTENCE =====================
    void saveToFile() const;
    void loadFromFile();

    // ===================== DISPLAY =====================
    void displayMenu() const;
    std::string getName() const { return airlineName; }
};

#endif // AIRLINE_H
